from django.apps import AppConfig


class WipecardetailingConfig(AppConfig):
    name = 'wipecardetailing'
