from django.apps import AppConfig


class SpanglishConfig(AppConfig):
    name = 'spanglish'
